<?php

require_once "model.php";

class DocumentoUsuarioModel extends Model {
	
}