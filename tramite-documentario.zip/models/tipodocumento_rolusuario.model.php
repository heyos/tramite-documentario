<?php

require_once "model.php" ;

class TipoDocumentoRolUsuarioModel extends Model {
  
}
