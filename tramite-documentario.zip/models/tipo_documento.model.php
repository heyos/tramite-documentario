<?php

require_once "model.php";

class TipoDocumentoModel extends Model {

}
