
<div class="row">
    <div class="col-md-12">
        <!-- DASHBOARD -->
        <div class="text-primary">
            Mis Documentos
        </div>
        <hr>
        <div class="stat-panel" style="margin-top: 30px;margin-bottom:0px;">
            <div class="stat-row">
                <div class="col-sm-3 text-center" style="color: #555555;">
                    <i class="fa fa-exclamation-circle fa-2x text-warning"></i> 
                    <span style="font-size: 26px;">0</span>
                    <p>Pendientes</p>
                </div>
                <div class="col-sm-3 text-center" style="color: #555555;">
                    <i class="fa  fa-clock-o fa-2x text-primary" ></i> 
                    <span style="font-size: 26px;">143</span>
                    <p>En Proceso <br> de Firma</p>
                </div>
                <div class="col-sm-3 text-center" style="color: #555555;">
                    <i class="fa fa-check-circle fa-2x text-success"></i> 
                    <span style="font-size: 26px;">156262</span>
                    <p>Firmado por <br> Todos</p>
                </div>
                <div class="col-sm-3 text-center" style="color: #555555;">
                    <i class="fa fa-times-circle fa-2x" style="color: #23272D"></i> 
                    <span style="font-size: 26px;">176262</span>
                    <p>Rechazados</p>
                </div>
            </div>
        </div>
    </div>
</div>

