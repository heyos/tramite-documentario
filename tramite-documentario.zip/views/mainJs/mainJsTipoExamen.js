init.push(function () {

    //aqui tu codigo
    
});