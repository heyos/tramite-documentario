<?php

class Template{

    public static function templateController(){

        include 'views/template.php';

    }
}