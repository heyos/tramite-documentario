<?php

require_once "controller.php";

class ResumenDocumentoUsuarioController extends Controller {

	public static function columnName($estado){
		$column = '';
		switch ($estado) {
			case '0':
				$column = 'pendientes';
				break;
			case '1':
				$column = 'proceso_de_firma';
				break;
			case '2':
				$column = 'firmado_todos';
				break;
			case '3':
				$column = 'rechazados';
				break;
			
			default:
				$column = 'pendientes';
				break;
		}

		return $column;

	}

	public static function detalleResumen($usuario_id){

		$where = array(
			'where' => array(
				['usuario_id',$usuario_id]
			),
			'useDeleted' => '0'
		);

		$datos = ResumenDocumentoUsuarioModel::firstOrAll($table,$where,'first');

		return $datos;
	}

	public static function crearResumen($params){

		$respuestaOk = false;
      	$mensajeError = "No se puede ejecutar la aplicacion";
      	$contenidoOk = [];

		$table = "resumen_documento_usuario";
		$column = self::columnName($params['estado']);		

		$num = 0;

		$datos = self::detalleResumen($params['usuario_id']);

		if(!empty($datos)){

			$num = $datos[$column];
			$num += 1;
			
		}else{
			$num = 1;
		}

		$data = array(
			$column => $num,
			'fecha_modificacion' => date('Y-m-d'),
			'descripcion' => $column,
			'usuario_id' => $params['usuario_id'],
			'where' => array(
				['usuario_id' , $params['usuario_id']]
			),
			'useDeleted' => '0'
		);

		$respuesta = ResumenDocumentoUsuarioModel::createOrUpdate($table,$data);

		if($respuesta > 0){
			$respuestaOk = true;
			$mensajeError = "Se completo el proceso correctamente";
		}

		$salidaJson = array('respuesta'=>$respuestaOk,
                          	'mensaje'=>$mensajeError,
                          	'data'=>$contenidoOk);

      	return $salidaJson;

	}

	public static function updateResumen($params){

		$estado = 0;
		$where_documento = array(
			'where' => array(
				['id',$params['documento_id']]
			)
		);
		$documento = DocumentoModel::firstOrAll('documento',$where_documento,'first');
		$estado = !empty($documento) ? $documento['estado_firma'] : 0;		

		if($estado == 1){

			$whereFirmantes = array(
				'columns' => 'COUNT(*) AS cantidad',
				'table' => 'documento_usuario',
				'where' => array(
					['documento_id',$params['documento_id']],
					['deleted','0']
				)
			);
			$data = DocumentoUsuarioModel::all($whereFirmantes);
			$totalFirmantes = count($data) > 0 ? $data[0]['cantidad'] : 0;
			
			$whereFirmantes['where'][] = ['firmado','1'];
			$dataFirmas = DocumentoUsuarioModel::all($whereFirmantes);
			$totalFirmas = count($data) > 0 ? $data[0]['cantidad'] : 0;

			$estado = $totalFirmantes == $totalFirmas ? 2 : $estado;

		}
		

		$estado_old = $params['estado_old'];
		$column = self::columnName($estado);
		$column_old = self::columnName($estado_old);

		$resumen = self::detalleResumen($params['usuario_id']);

		$cantidad = !empty($resumen) ? $resumen[$column] : 0;
		$cantidad_old = !empty($resumen) ? $resumen[$column_old] : 0;


	}

}