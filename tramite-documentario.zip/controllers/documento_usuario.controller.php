<?php

require_once "controller.php";

class DocumentoUsuarioController extends Controller {

}